#include <QCoreApplication>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QMap>
#include <QVariant>
#include <QString>
#include <QDebug>

//#include "programtaskbuilder/builder.h"
#include "programtaskbuilder/director.h"
#include "programtaskbuilder/cuttingbuilder.h"


QVariant jsonValueToVariant(const QJsonValue& jsonValue) {
    switch (jsonValue.type()) {
    case QJsonValue::Object: {
        QJsonObject obj = jsonValue.toObject();
        QMap<QString, QVariant> map;
        for (auto it = obj.constBegin(); it != obj.constEnd(); ++it) {
            map.insert(it.key(), jsonValueToVariant(it.value()));
        }
        return QVariant::fromValue(map);
    }
    case QJsonValue::Array: {
        QJsonArray array = jsonValue.toArray();
        QList<QVariant> list;
        for (const QJsonValue& item : array) {
            list.append(jsonValueToVariant(item));
        }
        return QVariant::fromValue(list);
    }
    case QJsonValue::String:
        return jsonValue.toString();
    case QJsonValue::Double:
        return jsonValue.toDouble();
    case QJsonValue::Bool:
        return jsonValue.toBool();
    case QJsonValue::Null:
    case QJsonValue::Undefined:
        return QVariant(); // Null
    default:
        return QVariant();
    }
}

QMap<QString, QVariant> parseJsonToQMap(const QString& jsonString) {
    QJsonDocument doc = QJsonDocument::fromJson(jsonString.toUtf8());
    if (doc.isNull() || !doc.isObject()) {
        qDebug() << "Invalid JSON format";
        return QMap<QString, QVariant>();
    }

    QJsonObject jsonObj = doc.object();
    QMap<QString, QVariant> rootMap;
    for (auto it = jsonObj.constBegin(); it != jsonObj.constEnd(); ++it) {
        rootMap.insert(it.key(), jsonValueToVariant(it.value()));
    }
    return rootMap;
}

QString getJson()
{
    QString jsonString = R"({
    "device_name": "Frezer",
    "connection_type": "comport",
    "mission" : "key_manufacturing",
    "task": "cutting_by_database",
    "blanks_parameters": {
      "blank_root" : "FlatBlank",
      "blank_child": "ProfiledSymmetricalBaseStop",
      "Width": 8.3,
      "Thickness" : 2.3,
      "Length": 27.3
    },
    "rows":
    [
        {
        "row" :"1",
        "row_type" : "PerforatedRowOnSide",
        "cut_type": "Perforated",
        "row_parameters":
        {
            "LinePosition":2.6
        },
        "internal_name": "test",
        "external_name": "test",
        "cuts": [
          {
            "Base": 4.5,
            "Angle": 90,
            "Area": 0.8,
            "Code": 0.9
          },
          {
            "Base": 8.5,
            "Angle": 90,
            "Area": 0.8,
            "Code":  0.9
          },
          {
            "Base": 12.5,
            "Angle": 90,
            "Area": 0.8,
            "Code":  0.9
          },
          {
            "Base": 16.5,
            "Angle": 90,
            "Area": 0.8,
            "Code":  0.9
          },
          {
            "Base": 20.5,
            "Angle": 90,
            "Area": 0.8,
            "Code":  0.9
          }
        ]
      },
      {
        "row" :"2",
        "row_type" : "PerforatedRowOnSide",
        "cut_type": "Perforated",
        "row_parameters":
        {
            "LinePosition":5.7
        },
        "internal_name": "test",
        "external_name": "test",
        "cuts": [
          {
            "Base": 4.5,
            "Angle": 90,
            "Area": 0.8,
            "Code":  0.9
          },
          {
            "Base": 8.5,
            "Angle": 90,
            "Area": 0.8,
            "Code":  0.9
          },
          {
            "Base": 12.5,
            "Angle": 90,
            "Area": 0.8,
            "Code":  0.9
          },
          {
            "Base": 16.5,
            "Angle": 90,
            "Area": 0.8,
            "Code":  0.9
          },
          {
            "Base": 20.5,
            "Angle": 90,
            "Area": 0.8,
            "Code":  0.9
          }
        ]
      }
    ]
})";

    return jsonString;
}


int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    /*QList<double> main_pins = {2.1, 1.7, 1.3, 0.9, 0.5};
    QList<double> add_pins = {2.1, 1.7, 1.3};

    for (int i = 0; i < main_pins.count(); i++)
    {
        double main_pin = main_pins[i];
        qDebug() << "za? " << main_pin;

        for (int j = 0; j < add_pins.count(); j++)
        {
            double add_pin = add_pins[j];
            bool isValid = KeyValidation::isValidCodeCombination(main_pin, add_pin, 2.3);
            qDebug() << "главный пин: " << main_pin << " дополнительный пин: " << add_pin;
            qDebug() << "Валид? " << isValid;
        }
    }*/

    QString jsonString = getJson();
    QMap<QString, QVariant> dataMap = parseJsonToQMap(jsonString);

    Director* director = new Director();
    CuttingBuilder* cutting_builder = new CuttingBuilder(dataMap);

    director->setBuilder(cutting_builder);
    director->build();
    auto prog = cutting_builder->getProgram();

    return a.exec();
}
