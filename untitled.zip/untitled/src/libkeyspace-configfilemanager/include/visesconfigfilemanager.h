#pragma once

#include "configfilemanager.h"
#include "equipments/equipmentsbase/equipmenthorizontalorientation.h"
#include "equipments/equipmentsbase/equipmentverticalorientation.h"
#include <QList>

class VisesConfigFileManager : public ConfigFileManager
{
public:
    ///
    /// \brief получить список тисков для горизонтального "станка"
    /// \return
    ///
	QList<EquipmentHorizontalOrientation> getHorizontalVises();

    ///
    /// \brief получить список тисков для вертикального "станка"
    /// \return
    ///
	QList<EquipmentVerticalOrientation>   getVerticalVises();

    ///
    /// \brief найти тиски для горизонтального "станка"
    /// \param name
    /// \return
    ///
	EquipmentHorizontalOrientation        findHorizontalVises(const QString& name);

    ///
    /// \brief найти тиски для вертикального "станка"
    /// \param name
    /// \return
    ///
	EquipmentVerticalOrientation          findVerticalVises(const QString& name);


    // void addHorizontalEquipment(const EquipmentPosition &equipment);
    // void addVerticalEquipment(const EquipmentPosition &equipment);

private:
	static const QString  m_vises_file_name;

	EquipmentVerticalOrientation          jsonToEquipmentVerticalOrientation(const QJsonObject& json) const;
	EquipmentHorizontalOrientation        jsonToEquipmentHorizontalOrientation(const QJsonObject& json) const;
	QJsonObject                           equipmentToJson(const Equipment& equipment) const;
};
