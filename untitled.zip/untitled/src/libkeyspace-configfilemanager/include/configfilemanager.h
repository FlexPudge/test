#pragma once

#include <QJsonObject>
#include <QList>
#include <QString>

class ConfigFileManager
{
public:
	bool loadConfig(const QString& filePath);
	bool saveConfig(const QString& filePath);

protected:
	QJsonObject           m_jsonConfig;

private:
	static const QString  m_config_path;
};
