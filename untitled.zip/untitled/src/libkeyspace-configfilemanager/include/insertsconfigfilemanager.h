#pragma once

#include "configfilemanager.h"
#include "equipments/equipmentsbase/equipmenthorizontalorientation.h"
#include "equipments/equipmentsbase/equipmentverticalorientation.h"
#include <QList>

class InsertsConfigFileManager : public ConfigFileManager
{
public:
    ///
    /// \brief получить список вставок для горизонтального "станка"
    /// \return
    ///
    QList<EquipmentHorizontalOrientation> getHorizontalInserts();

    ///
    /// \brief получить список вставок для вертикального "станка"
    /// \return
    ///
    QList<EquipmentVerticalOrientation>   getVerticalInserts();

    ///
    /// \brief найти вставки для горизонтального "станка"
    /// \param name
    /// \return
    ///
    EquipmentHorizontalOrientation        findHorizontalInserts(const QString& name);

    ///
    /// \brief найти вставки для вертикального "станка"
    /// \param name
    /// \return
    ///
    EquipmentVerticalOrientation          findVerticalInserts(const QString& name);

private:
	static const QString  m_inserts_file_name;

	EquipmentVerticalOrientation          jsonToEquipmentVerticalOrientation(const QJsonObject& json) const;
	EquipmentHorizontalOrientation        jsonToEquipmentHorizontalOrientation(const QJsonObject& json) const;
	QJsonObject                           equipmentToJson(const Equipment& equipment) const;
};
