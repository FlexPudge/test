#pragma once

#include "configfilemanager.h"
#include "tools/cuttingtools/disccuttinmill.h"
#include "tools/cuttingtools/discshapedmill.h"
#include "tools/cuttingtools/endcylindricalmill.h"
#include "tools/cuttingtools/endshapedmill.h"
#include "tools/cuttingtools/mill.h"
#include <QList>

class MillConfigFileManager : public ConfigFileManager
{
public:
	QList<EndCylindricalMill> getEndCylindricalMills();
	QList<EndShapedMill>      getEndShapedMills();
	QList<DiscCuttingMill>    getDiscCuttingMills();
	QList<DiscShapedMill>     getDiscShapedMills();

	Mill                      findMillByName(const QString& name);

private:
	static const QString  m_mills_file_name;

	EndCylindricalMill        jsonToEndCylindricalMill(const QJsonObject& json) const;
	EndShapedMill             jsonToEndShapedMill(const QJsonObject& json) const;
	DiscCuttingMill           jsonToDiscMill(const QJsonObject& json) const;
	DiscShapedMill            jsonToDiscShapedMill(const QJsonObject& json) const;
};
