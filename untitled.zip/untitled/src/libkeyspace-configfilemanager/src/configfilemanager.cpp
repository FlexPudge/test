#include "configfilemanager.h"
#include <QDebug>
#include <QDir>
#include <QFile>
#include <QJsonDocument>

const QString ConfigFileManager::m_config_path = "res/";

bool ConfigFileManager::loadConfig(const QString& filePath)
{
	QString currentDir = QDir::currentPath() + "/src/libkeyspace-configfilemanager";

	QFile   file(currentDir + "//" + filePath);

	if (!file.open(QIODevice::ReadOnly))
	{
		qDebug() << "Cannot open file: " << filePath;
		return false;
	}

	QByteArray    data = file.readAll();
	file.close();

	QJsonDocument doc = QJsonDocument::fromJson(data);
	if (doc.isNull() || !doc.isObject())
	{
		qDebug() << "Invalid JSON format";
		return false;
	}

	m_jsonConfig = doc.object();
	return true;
}


bool ConfigFileManager::saveConfig(const QString &filePath)
{
    return false;
}
