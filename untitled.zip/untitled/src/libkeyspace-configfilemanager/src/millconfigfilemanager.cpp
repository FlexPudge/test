#include "millconfigfilemanager.h"
#include <QJsonArray>

const QString MillConfigFileManager::m_mills_file_name = "mills.json";

QList<EndCylindricalMill> MillConfigFileManager::getEndCylindricalMills()
{
	bool isLoadConfig = loadConfig(m_mills_file_name);

	if (isLoadConfig == true)
	{
		QList<EndCylindricalMill> result;

		if (m_jsonConfig.contains("EndCylindricalMills"))
		{
			QJsonArray array = m_jsonConfig["EndCylindricalMills"].toArray();
			for (const auto& item : array)
			{
				result.append(jsonToEndCylindricalMill(item.toObject()));
			}
		}

		return result;
	}

	return {};
}

QList<EndShapedMill> MillConfigFileManager::getEndShapedMills()
{
	bool isLoadConfig = loadConfig(m_mills_file_name);

	if (isLoadConfig == true)
	{
		QList<EndShapedMill> result;

		if (m_jsonConfig.contains("EndShapedMills"))
		{
			QJsonArray array = m_jsonConfig["EndShapedMills"].toArray();
			for (const auto& item : array)
			{
				result.append(jsonToEndShapedMill(item.toObject()));
			}
		}

		return result;
	}

	return {};
}

QList<DiscCuttingMill> MillConfigFileManager::getDiscCuttingMills()
{
	bool isLoadConfig = loadConfig(m_mills_file_name);

	if (isLoadConfig == true)
	{
		QList<DiscCuttingMill> result;

		if (m_jsonConfig.contains("DiscCuttingMills"))
		{
			QJsonArray array = m_jsonConfig["DiscCuttingMills"].toArray();
			for (const auto& item : array)
			{
				result.append(jsonToDiscMill(item.toObject()));
			}
		}

		return result;
	}

	return {};
}

QList<DiscShapedMill> MillConfigFileManager::getDiscShapedMills()
{
	bool isLoadConfig = loadConfig(m_mills_file_name);

	if (isLoadConfig == true)
	{
		QList<DiscShapedMill> result;

		if (m_jsonConfig.contains("DiscShapedMills"))
		{
			QJsonArray array = m_jsonConfig["DiscShapedMills"].toArray();
			for (const auto& item : array)
			{
				result.append(jsonToDiscShapedMill(item.toObject()));
			}
		}

		return result;
	}

	return {};
}

EndCylindricalMill MillConfigFileManager::jsonToEndCylindricalMill(const QJsonObject& json) const
{
	EndCylindricalMill mill;

	mill.name = json["name"].toString();
	mill.length = json["name"].toDouble();
	mill.diameter_working_part = json["diameter_working_part"].toDouble();
	mill.milling_speed = json["milling_speed"].toDouble();
	return mill;
}

EndShapedMill MillConfigFileManager::jsonToEndShapedMill(const QJsonObject& json) const
{
	EndShapedMill mill;

	mill.name = json["name"].toString();
	mill.length = json["name"].toDouble();
	mill.diameter_platform = json["diameter_platform"].toDouble();
	mill.angle_cutting_part = json["angle_cutting_part"].toDouble();
	mill.milling_speed = json["milling_speed"].toDouble();
	return mill;
}

DiscCuttingMill MillConfigFileManager::jsonToDiscMill(const QJsonObject& json) const
{
	DiscCuttingMill mill;

	mill.name = json["name"].toString();
	mill.thickness = json["thickness"].toDouble();
	mill.outer_diametr = json["outer_diametr"].toDouble();
	mill.milling_speed = json["milling_speed"].toDouble();
	return mill;
}

DiscShapedMill MillConfigFileManager::jsonToDiscShapedMill(const QJsonObject& json) const
{
	DiscShapedMill mill;

	mill.name = json["name"].toString();
	mill.thickness = json["thickness"].toDouble();
	mill.outer_diametr = json["outer_diametr"].toDouble();
	mill.angle_cutting_part = json["angle_cutting_part"].toDouble();
	mill.milling_speed = json["milling_speed"].toDouble();
	return mill;
}
