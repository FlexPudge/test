#include "visesconfigfilemanager.h"
#include <QJsonArray>

const QString VisesConfigFileManager::m_vises_file_name = "vises.json";

QList<EquipmentHorizontalOrientation> VisesConfigFileManager::getHorizontalVises()
{
	bool isLoadConfig = loadConfig(m_vises_file_name);

	if (isLoadConfig == true)
	{
		QList<EquipmentHorizontalOrientation> result;

		if (m_jsonConfig.contains("EquipmentHorizontalOrientation"))
		{
			QJsonArray array = m_jsonConfig["EquipmentHorizontalOrientation"].toArray();
			for (const auto& item : array)
			{
				result.append(jsonToEquipmentHorizontalOrientation(item.toObject()));
			}
		}

		return result;
	}

	return {};
}

QList<EquipmentVerticalOrientation> VisesConfigFileManager::getVerticalVises()
{
	bool isLoadConfig = loadConfig(m_vises_file_name);

	if (isLoadConfig == true)
	{
		QList<EquipmentVerticalOrientation> result;

		if (m_jsonConfig.contains("EquipmentVerticalOrientation"))
		{
			QJsonArray array = m_jsonConfig["EquipmentVerticalOrientation"].toArray();
			for (const auto& item : array)
			{
				result.append(jsonToEquipmentVerticalOrientation(item.toObject()));
			}
		}

		return result;
	}

	return {};
}

EquipmentHorizontalOrientation VisesConfigFileManager::findHorizontalVises(const QString& name)
{
	bool isLoadConfig = loadConfig(m_vises_file_name);

	if (isLoadConfig == true)
	{
		QJsonArray array = m_jsonConfig["EquipmentHorizontalOrientation"].toArray();
		for (const QJsonValue& value : array)
		{
			QJsonObject obj = value.toObject();
			QString     equipmentName = obj["name"].toString();
			if (equipmentName.compare(name, Qt::CaseInsensitive) == 0)
			{
				EquipmentHorizontalOrientation equipment = jsonToEquipmentHorizontalOrientation(obj);
				return equipment;
			}
		}
	}

	return {};
}

EquipmentVerticalOrientation VisesConfigFileManager::findVerticalVises(const QString& name)
{
	bool isLoadConfig = loadConfig(m_vises_file_name);

	if (isLoadConfig == true)
	{
		QJsonArray array = m_jsonConfig["EquipmentHorizontalOrientation"].toArray();
		for (const QJsonValue& value : array)
		{
			QJsonObject obj = value.toObject();
			QString     equipmentName = obj["name"].toString();
			if (equipmentName.compare(name, Qt::CaseInsensitive) == 0)
			{
				EquipmentVerticalOrientation equipment = jsonToEquipmentVerticalOrientation(obj);
				return equipment;
			}
		}
	}

	return {};
}

EquipmentVerticalOrientation VisesConfigFileManager::jsonToEquipmentVerticalOrientation(const QJsonObject& json) const
{
	EquipmentVerticalOrientation equipment;

	equipment.name = json["name"].toString();
	equipment.x = json["x"].toDouble();
	equipment.y = json["y"].toDouble();
	equipment.z = json.value("z").toDouble();

	return equipment;
}

EquipmentHorizontalOrientation VisesConfigFileManager::jsonToEquipmentHorizontalOrientation(
	const QJsonObject& json) const
{
	EquipmentHorizontalOrientation equipment;

	equipment.name = json["name"].toString();
	equipment.x = json["x"].toDouble();
	equipment.y = json["y"].toDouble();

	return equipment;
}
