#include "insertsconfigfilemanager.h"
#include <QJsonArray>

const QString InsertsConfigFileManager::m_inserts_file_name= "inserts.json";

QList<EquipmentHorizontalOrientation> InsertsConfigFileManager::getHorizontalInserts()
{
    bool isLoadConfig = loadConfig(m_inserts_file_name);

    if (isLoadConfig == true)
    {
        QList<EquipmentHorizontalOrientation> result;

        if (m_jsonConfig.contains("EquipmentHorizontalOrientation"))
        {
            QJsonArray array = m_jsonConfig["EquipmentHorizontalOrientation"].toArray();
            for (const auto& item : array)
            {
                result.append(jsonToEquipmentHorizontalOrientation(item.toObject()));
            }
        }

        return result;
    }

    return {};
}

QList<EquipmentVerticalOrientation> InsertsConfigFileManager::getVerticalInserts()
{
    bool isLoadConfig = loadConfig(m_inserts_file_name);

    if (isLoadConfig == true)
    {
        QList<EquipmentVerticalOrientation> result;

        if (m_jsonConfig.contains("EquipmentVerticalOrientation"))
        {
            QJsonArray array = m_jsonConfig["EquipmentVerticalOrientation"].toArray();
            for (const auto& item : array)
            {
                result.append(jsonToEquipmentVerticalOrientation(item.toObject()));
            }
        }

        return result;
    }

    return {};
}

EquipmentHorizontalOrientation InsertsConfigFileManager::findHorizontalInserts(const QString &name)
{
    return {};
}

EquipmentVerticalOrientation InsertsConfigFileManager::findVerticalInserts(const QString& name)
{
    return {};
}

EquipmentVerticalOrientation InsertsConfigFileManager::jsonToEquipmentVerticalOrientation(const QJsonObject& json) const
{
    EquipmentVerticalOrientation equipment;

    equipment.name = json["name"].toString();
    equipment.x = json["x"].toDouble();
    equipment.y = json["y"].toDouble();
    equipment.z = json.value("z").toDouble();

    return equipment;
}

EquipmentHorizontalOrientation InsertsConfigFileManager::jsonToEquipmentHorizontalOrientation(
    const QJsonObject& json) const
{
    EquipmentHorizontalOrientation equipment;

    equipment.name = json["name"].toString();
    equipment.x = json["x"].toDouble();
    equipment.y = json["y"].toDouble();

    return equipment;
}
