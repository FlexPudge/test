#pragma once

#include <QObject>


class FrezerDispatcher
{
public:
    FrezerDispatcher();
    ~FrezerDispatcher();

    ///
    /// \brief Планировщик нарезки
    ///
    //void cuttingPlanner(const CuttingProgram* cutting_program);

    ///
    /// \brief Планировщик сканирования
    ///
    //void scanningPlanner(const ScanningProgram* scanning_program);
};
