#pragma once

#include <cstdint>
#include <QList>

#include "Commands/OperatingMode.h"

class Protocol
{
public:

    ///
    /// \brief Задать перемещение
    ///
	void    SetMovement();

    ///
    /// \brief Стоп
    ///
	void    Stop();

    ///
    /// \brief Режим работы
    ///
	void    SelectedOperatingMode(OperatingMode  mode);

    ///
    /// \brief Запрос координат
    ///
	void    RequestingCoordinates();

    ///
    /// \brief Запрос прогресса выполнения
    ///
	void    RequestProgress();

private:
	QList<uint8_t>  packet;
	int             count_command;

    ///
    /// \brief Метод для расчета контрольной суммы
    /// \return
    ///
	uint8_t CRC();
};
