#pragma once

#include <cstdint>

///
/// \brief Команды для запросов
///
enum class RequestsCommands : uint8_t
{
    /// 'c' - Запрос координат
	COORD_REQ    = 0x63,
    /// 'p' - Запрос прогресса
	PROGRESS_REQ = 0x70
};
