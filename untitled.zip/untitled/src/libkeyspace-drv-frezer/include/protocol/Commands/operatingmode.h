#pragma once

#include <cstdint>

///
/// \brief Режим работы
///
enum class OperatingMode : uint8_t
{
    /// Режим резки
	CUTING   = 0x01,
    /// Режим сканирования
	SCANNING = 0x02,
    /// Режим песочницы
	SANDBOX  = 0x03
};
