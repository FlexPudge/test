#pragma once

#include <cstdint>

///
/// \brief Протокольные команды
///
enum class COMMAND : uint8_t
{
    /// '#'
	START        = 0x23,
    /// 'k' - Количество команд
	CMD_COUNT    = 0x6B,
    /// 'X' - Ось X
	AXIS_X       = 0x58,
    /// 'Y' - Ось Y
	AXIS_Y       = 0x59,
    /// 'Z' - Ось Z
	AXIS_Z       = 0x5A,
    /// 'A' - Ось (поворотная ось)
	AXIS_A       = 0x41,
    /// 'M' - Команда перемещения
	MOVE         = 0x4D,
    /// 'S' - Команда вращения шпинделя
	SPINDLE      = 0x53,
    /// 'e' - Выбор режима
	MODE         = 0x65,
    /// 't' - Стоп
	STOP         = 0x74,
    /// 'D' - Шпиндель дисковой фрезы
	SPINDLE_DISK = 0x44,
    /// 'K' - Шпиндель концевой фрезы
	SPINDLE_END  = 0x4B
};
