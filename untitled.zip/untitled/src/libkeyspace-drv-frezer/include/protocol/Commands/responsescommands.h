#pragma once

#include <cstdint>

///
/// \brief Ответы на команды
///
enum class ResponsesCommands : uint8_t
{
    /// ID ответа на обычные команды
	RESP_DEFAULT  = 0xF0,
    /// ID ответа на запрос координат
	RESP_COORD    = 0xF1,
    /// ID ответа на прогресс
	RESP_PROGRESS = 0xF2
};
