#pragma once

#include <cstdint>

///
/// \brief Ошибки
///
enum class ErrorCode : uint8_t
{
    ///Пакет принят и успешно обработан
	OK                    = 0x00,
    ///Неверный стартовый символ в сообщении
	INVALID_START         = 0x01,
    ///Неверное количество байт в сообщении
	INVALID_BYTE_COUNT    = 0x02,
    ///Неверная контрольная сумма
	INVALID_CRC           = 0x03,
    ///Неизвестная команда
	UNKNOWN_COMMAND       = 0x04,
    ///Неверное количество команд
	INVALID_COMMAND_COUNT = 0x05,
    ///Команда запуска шпинделя в режиме сканирования
	SPINDLE_IN_SCAN_MODE  = 0x06
};
