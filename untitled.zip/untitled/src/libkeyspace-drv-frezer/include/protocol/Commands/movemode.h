#pragma once

#include <cstdint>

///
/// \brief Режим перемещения (Скорость перемещения мм/с)
///
enum class MoveMode : uint8_t
{
    ///X, Y синхронно, A/Z асинхронно
	STANDART  = 0x00,
    /// X, Y, Z синхронно, A асинхронно
	XYZ_SYNC  = 0x01,
    /// X, Y, A синхронно, Z асинхронно
	XYA_SYNC  = 0x02,
    /// Все асинхронно
	ALL_ASYNC = 0x03
};
