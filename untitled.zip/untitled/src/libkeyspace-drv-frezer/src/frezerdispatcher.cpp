#include "frezerdispatcher.h"

FrezerDispatcher::FrezerDispatcher()
{

}
