#pragma once

#include "cut.h"

struct PerforatedCut : public Cut
{
    ///
    /// \brief Угол выреза
    ///
	int  angle = 0;
    ///
    /// \brief Площадка выреза
    ///
	double  area = 0.0;
};
