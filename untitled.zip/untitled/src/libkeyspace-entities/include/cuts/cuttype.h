#pragma once

enum class CutType
{
	None,
	Perforated
};
