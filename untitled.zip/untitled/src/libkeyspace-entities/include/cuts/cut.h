#pragma once

#include "cuttype.h"
#include <QList>
#include <QMap>
#include <QObject>
#include <QString>
#include <QVariant>

struct Cut
{
	virtual ~Cut() = default;


    ///
    /// \brief Тип выреза
    ///
	CutType  cut_type = CutType::None;

    ///
    /// \brief Расстояние от точки упора до центра выреза
    ///
	double  base = 0.0;

    ///
    /// \brief Кодовый размер
    ///
	double  code = 0.0;
};
