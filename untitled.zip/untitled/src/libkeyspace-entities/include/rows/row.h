#pragma once

#include <QList>
#include <QString>
#include <QVariant>
#include <QMap>
#include "rowtype.h"
#include "cuts/cut.h"

///
/// \brief Ряд
///
struct Row
{
    virtual ~Row() = default;

    QList<Cut*>  cuts;
    RowType      row_type = RowType::None;
};
