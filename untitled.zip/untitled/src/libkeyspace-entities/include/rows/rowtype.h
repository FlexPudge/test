#pragma once

///
/// \brief Тип ряда
///
enum class RowType
{
	None,
    ///Перфорированный ряд
    Perforated_on_side,
    ///Английский
	English
};
