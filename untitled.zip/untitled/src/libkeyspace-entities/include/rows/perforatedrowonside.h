#pragma once

#include "row.h"

///
/// \brief Перфорированный ряд на ребре
///
struct PerforatedRowOnSide : public Row
{
    ///
    /// \brief Смещение ряда
    ///
	double  line_position = 0.0;
};
