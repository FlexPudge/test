#pragma once

#include "flatblank.h"

///
/// \brief Плоская несимметричная
///
struct FlatBlankNonSymmetric : public FlatBlank
{
    ///
    /// \brief Длина рабочей части заготовки, имеющей наибольшую длину
    ///
	double  length_larger_side;

    ///
    /// \brief Длина рабочей части заготовки, имеющей наименьшую длину
    ///
	double  length_smaller_side;

    ///
    /// \brief Ширина рабочей части
    ///
	double  width;

    ///
    /// \brief Толщина рабочей части
    ///
	double  thickness;
};
