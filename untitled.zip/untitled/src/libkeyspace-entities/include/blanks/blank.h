#pragma once

struct Blank
{

};
