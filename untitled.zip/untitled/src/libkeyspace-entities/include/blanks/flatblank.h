#pragma once

#include "blank.h"

enum Support
{
    ///Упор в торец
	Face,
    ///Упло в базовые выступы
	Base
};

///
/// \brief Плоская профильная заготовка
///
struct FlatBlank : public Blank
{
    ///
    /// \brief Базовый упор
    ///
	Support  support;
    ///
    /// \brief Ширина
    ///
	double  width;
    ///
    /// \brief Толщина
    ///
	double  thickness;
};
