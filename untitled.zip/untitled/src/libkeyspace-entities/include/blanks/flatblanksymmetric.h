#pragma once

#include "flatblank.h"

///
/// \brief Плоская симметричная
///
struct FlatBlankSymmetric : public FlatBlank
{
    ///
    /// \brief Длина
    ///
	double  length;
};
