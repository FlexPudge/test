#pragma once

#include "equipment.h"

///
/// \brief Оснастка для горизонтальной работы (станок тип 1)
///
struct EquipmentHorizontalOrientation : public Equipment
{
    double  a = 0.0;
};
