#pragma once

#include <QString>
///
/// \brief Класс оснастки (тиски и вставки)
///
struct Equipment
{
    QString  name;
    QString  image_path;
    double   x = 0.0;
    double   y = 0.0;
};
