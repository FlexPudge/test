#pragma once

#include "equipment.h"

///
/// \brief Оснастка для вертикальной работы (станок тип 2)
///
struct EquipmentVerticalOrientation : public Equipment
{
    double  z = 0.0;
};
