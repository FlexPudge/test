#pragma once

#include "equipments/equipmentsbase/equipmentverticalorientation.h"

struct ViseTypeTwo : public EquipmentVerticalOrientation
{

};
