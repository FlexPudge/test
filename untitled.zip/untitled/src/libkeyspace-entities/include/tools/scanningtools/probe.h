#pragma once

#include "scanner.h"

///
/// \brief Щуп
///
struct Probe : public Scanner
{};
