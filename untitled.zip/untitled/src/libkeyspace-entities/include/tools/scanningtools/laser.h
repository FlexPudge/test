#pragma once

#include "scanner.h"

///
/// \brief Лазер
///
struct Laser : public Scanner
{};
