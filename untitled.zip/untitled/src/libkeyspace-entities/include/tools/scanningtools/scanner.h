#pragma once

#include "QString"

///
/// \brief Инструмент сканирования
///
struct Scanner
{
	QString  name;
};
