#pragma once

#include "QString"

///
/// \brief Фреза
///
struct Mill
{
    ///
    /// \brief Название
    ///
    ///
	QString  name;

    ///
    /// \brief Скорость перемещения при нарезании (мм)
    ///
	int  milling_speed = 0;
};
