#pragma once

#include "mill.h"

struct EndMill : public Mill
{
    ///
    /// \brief Длина
    ///
	double  length;
};
