#pragma once

#include "endmill.h"

///
/// \brief Концевая цилиндрическая фреза
///
struct EndCylindricalMill : public EndMill
{
    ///
    /// \brief Диаметр рабочей части
    ///
	double  diameter_working_part = 0.0;
};
