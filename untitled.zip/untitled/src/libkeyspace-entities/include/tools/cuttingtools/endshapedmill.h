#pragma once

#include "endmill.h"

///
/// \brief Концевая фасонная фреза
///
struct EndShapedMill : public EndMill
{
    ///
    /// \brief Диаметр площадки
    ///
	double  diameter_platform = 0;
    ///
    /// \brief Угол режущей части
    ///
	double  angle_cutting_part = 0;
};
