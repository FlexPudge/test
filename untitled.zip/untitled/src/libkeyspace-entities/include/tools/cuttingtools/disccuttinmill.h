#pragma once

#include "discmill.h"

///
/// \brief Дисковая отрезная фреза
///
struct DiscCuttingMill : public DiscMill
{};
