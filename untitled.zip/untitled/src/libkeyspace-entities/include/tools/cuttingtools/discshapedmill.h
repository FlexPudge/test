#pragma once

#include "discmill.h"

///
/// \brief Дисковая фасонная фреза
///
struct DiscShapedMill : public DiscMill
{
    ///
    /// \brief Угол режущей части
    ///
	double  angle_cutting_part = 0.0;
};
