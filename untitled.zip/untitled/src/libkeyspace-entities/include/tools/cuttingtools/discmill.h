#pragma once

#include "mill.h"

struct DiscMill : public Mill
{
    ///
    /// \brief Толщина
    ///
	double  thickness;
    ///
    /// \brief Внешний диаметр
    ///
	double  outer_diametr;
};
