#pragma once

enum class Device
{
    HorizontalOrientation,
    VerticalOrientation
};
