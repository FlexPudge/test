#pragma once

#include <QList>

class KeyValidation
{
public:
    KeyValidation();

    ///
    /// \brief Проверка соотношений кодовых типоразмеров
    /// \param main_pin - код основного ряда
    /// \param additional_pin - код дополнительного ряда
    /// \param blank_thickness - толщина заготовки
    /// \return true - вырезы не пересекаются, false - вырезы пересекаются
    ///
    static bool isValidCodeCombination(double main_pin,double additional_pin, double blank_thickness);

    ///
    /// \brief Проверка глубины выреза
    /// \param depth_code - глубина выреза
    /// \param blank_thickness - толщина (ширина) заготовки
    /// \return
    ///
    static bool isValidDepthCode(double depth_code, double blank_thickness);

    ///
    /// \brief Проверка базы выреза
    /// \param base_cut - база выреза
    /// \param blank_thickness - длина заготовки
    /// \return
    ///
    static bool isValidBaseCode(double base_cut, double blank_length);

    static bool isValidKeyParameters();

};
