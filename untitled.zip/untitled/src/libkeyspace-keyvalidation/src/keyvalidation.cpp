#include "keyvalidation.h"
#include <QDebug>

KeyValidation::KeyValidation()
{}

bool KeyValidation::isValidCodeCombination(double main_pin, double additional_pin, double blank_thickness)
{
	double depth_main_pin = std::abs(blank_thickness - main_pin);
	double depth_additional_pin = std::abs(blank_thickness - additional_pin);
	double difference = depth_main_pin + depth_additional_pin;

	if (difference < blank_thickness)
	{
		return true;
	}

    return false;
}

bool KeyValidation::isValidDepthCode(double depth_code, double blank_thickness)
{
    if(depth_code < blank_thickness)
    {
        return true;
    }

    return false;
}

bool KeyValidation::isValidBaseCode(double base_cut, double blank_length)
{
    if(base_cut > 0.5 || base_cut < blank_length)
    {
        return true;
    }

    return false;
}
