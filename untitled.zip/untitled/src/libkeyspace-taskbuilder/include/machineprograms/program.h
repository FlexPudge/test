#pragma once

#include "blanks/blank.h"
#include "subprogram/subprogram.h"
#include <QList>

struct Program
{
    Blank*              blank_parameters = nullptr;
    QList<SubProgram*>  sub_program;

    ~Program() {
        delete blank_parameters;
        qDeleteAll(sub_program);
    }
};
