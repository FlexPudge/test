#pragma once

#include "blanks/blank.h"
#include "equipments/equipmentsbase/equipment.h"
#include "program.h"
#include "subprogram.h"
#include "tools/cuttingtools/mill.h"
#include <QVariant>



class Converter
{
public:
	static SubProgram* createSubProgram(const QMap<QString, QVariant>& contextData);
	static Blank*      createBlank(const QMap<QString, QVariant>& blankData);
	static Row*        createRow(const QMap<QString, QVariant>& rowData);
	static QList<Cut*> createCut(const QMap<QString, QVariant>& cutData);
    static Equipment*  createVise(const RowType&  row_type);
    static Equipment*  createInserts(const RowType&  row_type);
    static Mill*       createMill(const RowType&  row_type);
};
