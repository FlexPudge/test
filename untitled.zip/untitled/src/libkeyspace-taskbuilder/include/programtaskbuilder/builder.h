#pragma once

#include "machineprograms/program.h"
#include <QJsonDocument>
#include <QJsonObject>

///
/// \brief Сборщик программ
///
class Builder
{
public:

    Builder(const QMap<QString, QVariant> &data);

    virtual ~Builder() {};


    ///
    /// \brief GetProgram
    /// \return
    ///
	virtual Program getProgram() = 0;

    ///
    /// \brief Параметры заготовки
    ///
	virtual void    producePartBlankParameter() = 0;

    ///
    /// \brief Подрограмма
    ///
    virtual void    producePartSubProgram() = 0;

protected:
    Program*       programm;
    QMap<QString, QVariant> context;
};
