#pragma once

#include <QJsonDocument>
#include "builder.h"

class Director
{
public:
    void setBuilder(Builder* builder);
    void build();


private:
    Builder* builder;
};
