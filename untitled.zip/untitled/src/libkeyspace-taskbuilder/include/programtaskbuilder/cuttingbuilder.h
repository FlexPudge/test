#pragma once

#include "builder.h"

///
/// \brief Сборщик программы нарезания на станке
///
class CuttingBuilder : public Builder
{
public:

    CuttingBuilder(const QMap<QString, QVariant> &data);
    ~CuttingBuilder();

	Program getProgram() override;

	void    producePartBlankParameter() override;

    void    producePartSubProgram() override;

private:
	void    reset();
};
