#pragma once

#include "builder.h"

///
/// \brief Сборщик программы сканирования на станке
///
class ScanningBuilder : public Builder
{
public:

	ScanningBuilder();


	Program getProgram() override;

	void    producePartBlankParameter() override;

    void    producePartSubProgram() override;
};
