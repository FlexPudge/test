#pragma once

#include <QList>
#include "subprogram.h"
#include "tools/cuttingtools/mill.h"
#include "equipments/equipmentsbase/equipment.h"

struct CuttingSubProgram : public SubProgram
{
    ///
    /// \brief Фреза
    ///
    Mill*  mill;

    ///
    /// \brief Тиски
    ///
    Equipment*  vise;

    ///
    /// \brief Вставки
    ///
    Equipment*  inserts;
};
