#pragma once

#include <QString>
#include "rows/row.h"

///
/// \brief Подпрограмма
///
struct SubProgram
{
    ///
    /// \brief Ряд
    ///
    Row*  row;
};
