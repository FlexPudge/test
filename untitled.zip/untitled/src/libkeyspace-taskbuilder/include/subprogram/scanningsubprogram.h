#pragma once

#include <QList>
#include "subprogram.h"
#include "tools/scanningtools/scanner.h"
#include "equipments/equipmentsbase/equipment.h"

struct ScanningSubProgram : public SubProgram
{
    ///
    /// \brief Сканер
    ///
    Scanner  scanner;

    ///
    /// \brief Тиски
    ///
    Equipment  vise;

    ///
    /// \brief Вставки
    ///
    QList<Equipment>  inserts;
};
