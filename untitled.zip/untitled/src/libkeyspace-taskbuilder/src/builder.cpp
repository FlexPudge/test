#include "builder.h"

Builder::Builder(const QMap<QString, QVariant> &data)
{
    context = data;
}
