#include "director.h"

void Director::setBuilder(Builder* builder)
{
    this->builder = builder;
}

void Director::build()
{
    this->builder->producePartBlankParameter();
    this->builder->producePartSubProgram();
}
