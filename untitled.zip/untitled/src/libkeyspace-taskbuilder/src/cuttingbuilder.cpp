#include "converter.h"
#include "cuttingbuilder.h"
#include "blanks/blank.h"


CuttingBuilder::CuttingBuilder(const QMap<QString, QVariant>& data)
	: Builder(data)
{
	reset();
}

CuttingBuilder::~CuttingBuilder()
{
	delete programm;
}

void CuttingBuilder::reset()
{
	this->programm = new Program();
}

Program CuttingBuilder::getProgram()
{
	return *programm;
}

void CuttingBuilder::producePartBlankParameter()
{
    QMap<QString, QVariant> blank_data = context.value("blanks_parameters").toMap();
    Blank* blank = Converter::createBlank(blank_data);
    if (blank != nullptr)
	{
		programm->blank_parameters = blank;
    }
}

void CuttingBuilder::producePartSubProgram()
{
    QVariantList rows_data = context.value("rows").toList();
    for (const QVariant& row_data : rows_data)
    {
        const QMap<QString, QVariant>& rowDataMap = row_data.toMap();
        programm->sub_program.push_back(Converter::createSubProgram(rowDataMap));
    }
}
