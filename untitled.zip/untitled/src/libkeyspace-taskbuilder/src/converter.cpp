#include "converter.h"
#include "cuttingsubprogram.h"
#include "blanks/flatblank.h"
#include "blanks/flatblanksymmetric.h"
#include "cuts/perforatedcut.h"
#include "rows/perforatedrowonside.h"
#include "configfilemanager.h"
#include "insertsconfigfilemanager.h"
#include "millconfigfilemanager.h"
#include "visesconfigfilemanager.h"

SubProgram* Converter::createSubProgram(const QMap<QString, QVariant>& contextData)
{
	CuttingSubProgram* subProgram = new CuttingSubProgram;

    subProgram->row = createRow(contextData);
    subProgram->row->cuts = createCut(contextData);
    subProgram->vise = createVise(subProgram->row->row_type);
    subProgram->mill = createMill(subProgram->row->row_type);
    subProgram->inserts = createInserts(subProgram->row->row_type);

    return subProgram;
}

Row* Converter::createRow(const QMap<QString, QVariant>& rowData)
{
	QString row_type = rowData.value("row_type").toString();

	if (row_type == "PerforatedRowOnSide")
	{
        PerforatedRowOnSide* row = new  PerforatedRowOnSide();
        QMap<QString, QVariant> row_params = rowData.value("row_parameters").toMap();
        row->row_type = RowType::Perforated_on_side;
        row->line_position = row_params.value("LinePosition").toDouble();
        return row;
	}

	return nullptr;
}


QList<Cut*> Converter::createCut(const QMap<QString, QVariant>& cutData)
{
	QList<Cut*>  cuts;
	QString      cut_type = cutData.value("cut_type").toString();
	QVariantList cuts_list = cutData.value("cuts").toList();

	if (cut_type == "Perforated")
	{
        for (const QVariant& cut_var : cuts_list)
		{
            QMap<QString, QVariant> cut_params = cut_var.toMap();
            PerforatedCut*          cut = new PerforatedCut();
            cut->cut_type = CutType::Perforated;
            cut->base = cut_params.value("Base").toDouble();
            cut->code = cut_params.value("Code").toDouble();
            cut->angle = cut_params.value("Angle").toDouble();
            cut->area = cut_params.value("Area").toDouble();
            cuts.push_back(cut);
        }

		return cuts;
	}

	return {};
}

Blank* Converter::createBlank(const QMap<QString, QVariant>& blankData)
{
    QString blank_root = blankData.value("blank_root").toString();
	QString blank_child = blankData.value("blank_child").toString();

	if ((blank_root == "FlatBlank") && (blank_child == "ProfiledSymmetricalBaseStop"))
	{
		FlatBlankSymmetric* blank = new FlatBlankSymmetric;
		blank->support = Support::Base;
		blank->width = blankData.value("Width").toDouble();
		blank->thickness = blankData.value("Thickness").toDouble();
		blank->length = blankData.value("Length").toDouble();
		return blank;
	}
    return nullptr;
}

Equipment* Converter::createVise(const RowType&  row_type)
{
    VisesConfigFileManager visesConfigFileManager;
    if(row_type == RowType::Perforated_on_side)
    {
    }
	return nullptr;
}

Equipment* Converter::createInserts(const RowType&  row_type)
{
    return nullptr;
}

Mill* Converter::createMill(const RowType&  row_type)
{
	return nullptr;
}

